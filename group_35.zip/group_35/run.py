import numpy as np
import pandas as pd

from sklearn.metrics import fbeta_score
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer, TfidfTransformer
from sklearn.neighbors import KNeighborsClassifier

from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn import linear_model

import math
import os
import re
from scipy.sparse import hstack, csr_matrix
from collections import Counter

def read(X, dir):
    for i in range(X.shape[0]):
        x = X[i]
        x[0] = str(x[0])
        with open("data" + os.sep + "page" + os.sep + dir + "_" + str(i) + ".txt", "r") as f:
            text = f.read()
            if "404" in text or "404" in text: 
                text = "" 
        text = ''.join([i for i in text if not i.isdigit()])
        text = re.sub(r'\b\w{1,3}\b', '', text)
        text = text.replace('\n', ' ')
        x[2] = text
        x[5] = str(x[5]) 
    return X

def write(method, y_pred):
    with open("sample_submission_" + method + ".csv", "w") as f:
        f.write("article_id,category\n")
        for i, y in enumerate(y_pred):
            f.write(str(i + 1) + "," + str(y))
            f.write("\n")

def counter_cosine_similarity(y1, y2):
    y1 = Counter(y1)
    y2 = Counter(y2)
    y = set(y1).union(y2)
    dotprod = sum(y1.get(k, 0) * y2.get(k, 0) for k in y)
    magA = math.sqrt(sum(y1.get(k, 0)**2 for k in y))
    magB = math.sqrt(sum(y2.get(k, 0)**2 for k in y))
    return dotprod / (magA * magB)

trainData_2=pd.read_csv("data" + os.sep + "train_v2.csv", na_filter=False)
trainHeader_2 = trainData_2.columns.values
trainData_2 = trainData_2.values

X_train_2 = trainData_2[:, range(6)]
y_train_2 = trainData_2[:, 6]
y_train_2 = y_train_2.astype("int")

X_train_2 = read(X_train_2, "train_2")

testData_2=pd.read_csv("data" + os.sep + "test_v2.csv", na_filter=False)
testHeader_2 = testData_2.columns.values
testData_2 = testData_2.values

X_test_2 = testData_2[:, range(6)]
X_test_2 = read(X_test_2, "test_2")

X_train_2_tfidf = dict()
X_test_tfidf = dict()
for i in range(6):
    vectorizer = TfidfVectorizer(analyzer='word', stop_words="english", norm="l1")
    X_train_2_tfidf[i] = vectorizer.fit_transform(X_train_2[:, i])
    X_test_tfidf[i] = vectorizer.transform(X_test_2[:, i])

X_train_2_tfidf = hstack([X_train_2_tfidf[i] for i in range(1,5)])
X_test_tfidf = hstack([X_test_tfidf[i] for i in range(1,5)])

print(X_train_2_tfidf.shape)
print(X_test_tfidf.shape)


classifier = linear_model.SGDClassifier(max_iter=100)

classifier.fit(X_train_2_tfidf, y_train_2)
print("F2 Score : " + str(fbeta_score(y_train_2, classifier.predict(X_train_2_tfidf), average='macro', beta=2)))
print("Score : " + str(classifier.score(X_train_2_tfidf, y_train_2)))
print("Cosine Similarity : " + str(counter_cosine_similarity(list(y_train_2), list(classifier.predict(X_train_2_tfidf)))))

X_test_pred_sgd = classifier.predict(X_test_tfidf)
write("sgd", X_test_pred_sgd)


classifier = linear_model.RidgeClassifierCV()

classifier.fit(X_train_2_tfidf, y_train_2)
print("F2 Score : " + str(fbeta_score(y_train_2, classifier.predict(X_train_2_tfidf), average='macro', beta=2)))
print("Score : " + str(classifier.score(X_train_2_tfidf, y_train_2)))
print("Cosine Similarity : " + str(counter_cosine_similarity(list(y_train_2), list(classifier.predict(X_train_2_tfidf)))))

X_test_pred_rcv = classifier.predict(X_test_tfidf)


classifier = DecisionTreeClassifier(max_depth=40)

classifier.fit(X_train_2_tfidf, y_train_2)
print("F2 Score : " + str(fbeta_score(y_train_2, classifier.predict(X_train_2_tfidf), average='macro', beta=2)))
print("Score : " + str(classifier.score(X_train_2_tfidf, y_train_2)))
print("Cosine Similarity : " + str(counter_cosine_similarity(list(y_train_2), list(classifier.predict(X_train_2_tfidf)))))

X_test_pred_decision_tree = classifier.predict(X_test_tfidf)
write("decision_tree", X_test_pred_decision_tree)


for i in range(40, 60):
    for j in range(5):
        classifier = DecisionTreeClassifier(max_depth=i)
        classifier.fit(X_train_2_tfidf, y_train_2)
        if (i == 40 and j == 0):
            X_test_pred = classifier.predict(X_test_tfidf)
        else:
            X_test_pred = np.vstack([X_test_pred, classifier.predict(X_test_tfidf)])

X_test_pred_decision_tree_en = np.array([])
for i in range(X_test_pred.shape[1]):
    pred = X_test_pred[:,i]
    counts = np.bincount(pred)
    X_test_pred_decision_tree_en = np.append(X_test_pred_decision_tree_en, np.argmax(counts))
X_test_pred_decision_tree_en = X_test_pred_decision_tree_en.astype(int)

write("decision_tree_en", X_test_pred_decision_tree_en)


from collections import Counter
X_test_pred = []
for i in range(X_test_tfidf.shape[0]):
    c = Counter([X_test_pred_sgd[i], X_test_pred_rcv[i], X_test_pred_decision_tree_en[i]])
    if c.most_common()[0][1] == 1:
        X_test_pred.append(X_test_pred_decision_tree_en[i])
    else:
        X_test_pred.append(c.most_common()[0][0])
write("major", X_test_pred)