Group 35
HAN BIHUI	e0338161@u.nus.edu	
LIU YIJING	e0267719@u.nus.edu

Code Structure
code/pre_processing.py
- it is to fetch file from each URL and do some simple pre-processing;
- the code is not stable due to dynamic page loading time; sometimes we have to manually interrupt the procoss and restart;
- fetched contents are available in data/page/

run.py
- classify test data and generate output file