import numpy as np
import pandas as pd

import time
import os
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from bs4 import BeautifulSoup

trainData=pd.read_csv("data" + os.sep + "train.csv", na_filter=False)
trainHeader = trainData.columns.values
trainData = trainData.values

X_train = trainData[:, range(6)]
y_train = trainData[:, 6]
y_train = y_train.astype("int")

trainData_2=pd.read_csv("data" + os.sep + "train_v2.csv", na_filter=False)
trainHeader_2 = trainData_2.columns.values
trainData_2 = trainData_2.values

X_train_2 = trainData_2[:, range(6)]
y_train_2 = trainData_2[:, 6]
y_train_2 = y_train_2.astype("int")

testData_2=pd.read_csv("data" + os.sep + "test_v2.csv", na_filter=False)
testHeader_2 = testData_2.columns.values
testData_2 = testData_2.values

X_test_2 = testData_2[:, range(6)]

def read_url(dataset, dir):
    firefoxProfile = webdriver.FirefoxProfile()
    firefoxProfile.set_preference('permissions.default.stylesheet', 2)
    firefoxProfile.set_preference('permissions.default.image', 2)
    firefoxProfile.set_preference('dom.ipc.plugins.enabled.libflashplayer.so', False)
    firefoxProfile.set_preference("dom.max_script_run_time", 5)
    caps = DesiredCapabilities().FIREFOX
    caps["pageLoadStrategy"] = "eager"
    driver = webdriver.Firefox(firefox_profile=firefoxProfile, desired_capabilities=caps)
    for i in range(dataset.shape[0]):
        try:
            url = dataset[i][2]
            driver.get(url)
            htmlSource = driver.page_source
            with open("data" + os.sep + "page" + os.sep + dir + "_" + str(i) + ".txt", "w") as f:
                f.write(clean(htmlSource))
        except:
            with open("data" + os.sep + "page" + os.sep + dir + "_" + str(i) + ".txt", "w") as f:
                f.write("")

def clean(html):
    soup = BeautifulSoup(html)
    for tag in soup(["script", "style", "a", "li"]): 
        tag.extract()
    text = soup.get_text()
    lines = (line.strip() for line in text.splitlines())
    chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
    text = '\n'.join(chunk for chunk in chunks if chunk)
    return text

read_url(X_train, "train")

read_url(X_train_2, "train_2")

read_url(X_test_2, "test_2")